function sumOfCubedOddNumbers(arr) {
    let sum = 0;
  
    for (let num of arr) {
      if (typeof num !== 'number' || isNaN(num) || num % 2 === 0) {
        return undefined; 
        }
  
      sum += Math.pow(num, 3);
    }
  
    return sum;
  }
  
  console.log(sumOfCubedOddNumbers([1, 2, 3]));
  console.log(sumOfCubedOddNumbers([2, 'a', 3]));
  