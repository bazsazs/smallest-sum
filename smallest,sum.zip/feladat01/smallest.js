function findMin(arr, returnType) {
    if (returnType === 'value') {
      return Math.min(...arr);
    } else if (returnType === 'index') {
      return arr.indexOf(Math.min(...arr));
    } else {
      console.error('Invalid returnType. Use "value" or "index".');
    }
  }
  
  console.log(findMin([1, 2, 3, 4, 5], 'value'));
  console.log(findMin([1, 2, 3, 4, 5], 'index'));
  